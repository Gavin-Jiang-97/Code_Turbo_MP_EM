function par = para(varargin)

    par.num_ex = 1000 ;
    par.lambda = 0.05 ;   % sparsity
    par.M = 8  ;          % number of BS antennas  
    par.type = 'TDLC300' ;
    par.user_delay = 0 * 1e-9 ; % asynchronous scenario considered in future research
    par.T = 8  ;          %  number of OFDM symbols
    par.R = 4  ; 
    
    par.N = 72 * 20 ;      % the whole number of subcarrers
    par.K  = 1000 ;        %  numebr of access devices
    par.P_sc  = 72  ;      %  subcarriers used for K devices
    par.PT = par.P_sc * par.T ;      % length of pilot
    par.iter = 25  ;
    par.p_total =  par.PT ;      

    par.n_dbm = -109  ;
    par.sigma_w2 = 10^(par.n_dbm/10) ;  
    par.SNR = 15 ;
    par.d = 0.05 + 0.45 * rand (par.K,1) ;  % 0.05 - 0.5 Km   
    par.h_dB = -128.1 - 36.7*log10(par.d) ; % the large-scale fading is assumed to be compensated by device power control
    par.user_dbm = par.SNR - par.h_dB + par.n_dbm;   
    par.sigma_h2 =  10.^( (par.h_dB + par.user_dbm) / 10 ) ;      
    
    par.Num_error_max = 5e2;
    
end