function [p_false,p_mis,p_error,MSE] = Result_Turbo_MP(~,R,PT, K, M, h_B_post, interval,b_C_post , in_detect, h_f_ca, r)

    % Calculate the Perror and NMSE
    in_true = find (r'==1);
    
    % false alarm
    false = ismember(in_detect , in_true);
    p_false = sum(false==0) / sum(1-r) ;
    % miss detection
    mis = ismember(in_true, in_detect);
    p_mis = sum(mis==0) / sum(r) ; 

    p_error = ( sum(mis==0) + sum(false==0) ) / K ;
    
    h_B_est = zeros(1,K,M,R) ;
    
    % NMSE
    for i_block = 1 : R
        h_B_est(1,:,:,i_block) = h_B_post( : , (i_block-1)*M+1 : i_block*M );
    end  

    h_C_ext = zeros(1,K,M,R) ;
    h_C_ext(1,:,:,:) = b_C_post ;
    
    h_est = zeros(PT,K,M) ;
    
    for i_block = 1 : R       
            in_r =( (i_block-1)*PT/R+1 : i_block*PT/R )'; % the r-th block index
            h_est(in_r,:,:) = h_B_est(1,:,:,i_block) + interval .* h_C_ext(1,:,:,i_block) ;
    end
        

     MSE =  mean( abs( r .* h_f_ca - h_est ).^2 , 'all') / mean( abs( r .* h_f_ca).^2 , 'all') ;
    

end