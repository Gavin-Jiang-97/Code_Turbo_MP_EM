%%
% * Codes of paper ``Massive Connectivity Over MIMO-OFDM: Joint Activity Detection and Channel Estimation 
%                   With Frequency Selectivity Compensation"
% Wenjun Jiang
clear ; 
clc ;
% rng('default') ;

%% initializaiotn 
    par = para ;
    N = par.N ;     % the whole number of subcarrers
    K = par.K ;     %  numebr of access devices
    P_sc = par.P_sc ;      %  number of OFDM subcarriers
    T = par.T ;      %  number of OFDM symobls
    Num_error_max = par.Num_error_max ;
    lambda = par.lambda ; % device active probability
    PT = par.PT ;      % par.P_sc * par.T ; 
    R = par.R ;        % number of sub-blocks
    M = par.M ;        % number of BS antennas
    num_ex = par.num_ex ;
    iter = par.iter ;
    type = par.type ;
    SNR = par.SNR ; 
    sigma_w2 = par.sigma_w2 ;
    p_total = par.p_total ;  
    sigma_h2 = par.sigma_h2 ; 
    user_delay = par.user_delay ;   
    

    
for iter_SNR = 1 : length(par.SNR) 
    
    SNR = par.SNR(iter_SNR) ;
    sigma_h2 = par.sigma_h2(:,iter_SNR) ;
    y = zeros(PT,M) ;  h_f_ca = zeros(PT,K,M) ;  
    MSE = zeros(1,M); MSE_fail=zeros(1,M) ; 
    p_fal_sum = zeros(iter,1) ; p_error_BP_sum = zeros(iter,1) ;
    MSE_sum = zeros(iter,1) ; p_mis_sum = zeros(iter,1) ;  p_error_sum = zeros(iter,1) ; 
    interval = zeros(PT/R,1) ;
    for i = 1 : T
        interval(i : T : PT/R) = (1 : PT/T/R) - PT/(T*2)/ R ; % base vector for slope in block-wise linear model
    end 

    tic   
    % set thresholds to avoid inaccurate parameter estimates by EM, 
    % and appropriate thresholds can be obtained from historical data.
    gamma_ini  = sigma_h2(1) / ( sum( abs(interval).^2) / (PT/R) ) * 0.03 ;
    w_mul_min = 1 + 10^((SNR-10)/10) ; 
    pri_mul_max = 1.0 ; pri_mul_min = 0.5 ;   
    
%% Monte Carlo Simulation
    k_ex = 0 ;
    Num_error = 0 ;
    
  while Num_error < Num_error_max &&  k_ex < num_ex
        k_ex = k_ex + 1 ;
        sigma_w2 = par.sigma_w2 ;     
        % Active users 
        r = binornd( 1 , lambda , [ 1, K ] ) ; % 1 by N row vector
        Index_ac = find(r == 1) ;
        B_0 = fft( eye ( K ) ) /  sqrt(PT) ; % with coloumn normalization
        permuation = randperm( K ) ;
        Index_sel = permuation( 1: PT )' ;   % S
        A = B_0 ( Index_sel' , : ) ;         % partial-DFT with lowest PAPR

        
    %% multipath channel and received observation
     h_f = channel_f( P_sc, N, K, M, sigma_h2 , user_delay , type, Index_ac) ;
     for j = 1 : T
        spa = (j-1)*(PT/T)+1 : j*(PT/T) ;    
        h_f_ca(j:T:end ,:,:) = h_f ;
     end
     Ah_m = sum ( A .* h_f_ca .* r , 2) ;
     Ah_m = reshape(Ah_m,[PT,M]) ;
     y =  sqrt(p_total) * Ah_m + sqrt( sigma_w2/2 ) * ( randn(PT,M)+ 1i*randn(PT,M)  )  ; 


    %% Turbo-MP Receiver
    % ***** Please see Sec. IV-F about the matrix reorganization to enable a low-complexity implementation (using FFT). **** 
    % * intialization
    h_A_pri = zeros( K , M , R) ;  b_A_pri = zeros(K, M, R) ; b_C_post = zeros(K, M , R) ;
    h_A_ext = zeros( K , M , R) ;  h_A_post = zeros(K, M, R) ; v_A_ext = ones (R,M) ; 
    b_A_ext = zeros( K , M , R) ;  b_A_post = zeros( K , M , R); v_bA_ext = ones (R,M) ; 
    v_bC_post =  ones (R,M) ; b_C_ext = zeros( K , M , R) ; v_bC_ext =  ones (R,M) ; 
    v_hA_pri = mean(lambda * sigma_h2) * ones (R,M) ;  %  parameter initialization
    sigma_c2 = gamma_ini * ones(K,1) ;
    lambda_B_pri = lambda * ones(K,1) ; lambda_C_ext = 0.5 * ones(K,1) ;
    v_bA_pri = lambda * sigma_c2(1) * ones(R,M) ;
    v_B_test = ones(1,M*R) ; v_q_post = v_bA_pri ; v_C_test = ones(1,M*R);
    turbo = TurboMP_Receiver_EMnew(y,[],[],sigma_h2,0.1) ;
    sigma_w2_old = mean(abs(y).^2,[1,2]) ;  % / ( 10^(SNR/10) + 1 ) ;
    sigma_w2 = sigma_w2_old ; sigma_w2_EM_Bpost = 1 ; beta_1 = 1 ; gamma_1 = 1 ;
    Update_EM = 0 ;

    for j = 1 : iter
       %% modules A and B for h
        for i_block = 1 : R
        spa = PT/R * (i_block-1) + 1 : PT/R * i_block  ;  
        Index_s = Index_sel(spa') ;
        [ h_A_ext(:,:,i_block), v_A_ext(i_block,:) , ~ ,h_A_post(:,:,i_block) ] = turbo.ModuleA_h('P-DFT',spa,Index_s,...
            h_A_pri(:,:,i_block),v_hA_pri(i_block,:),b_A_pri(:,:,i_block),v_bA_pri(i_block,:),interval, K , PT , R , M , p_total ,sigma_w2);
        u_B_pri(:, (i_block-1)*M+1:i_block*M ) = h_A_ext( :,:,i_block ) ;
        v_uB_pri(:, (i_block-1)*M+1:i_block*M ) = v_A_ext( i_block,: )  ;
        end
        
        % * u corresponds to the estimates of H in the paper
        [u_B_ext,v_uB_ext,lambda_B_ext,in_detect_B,u_B_post,v_B_post,v_B_post_1] = turbo.ModuleB(u_B_pri,v_uB_pri,lambda_B_pri,R,M) ;

        
        if abs( mean(v_B_post)- mean(v_B_test))/mean(v_B_post) < 1e-1
            Update_C = 1 ;
        else
            Update_C = 0 ;
        end
         
        for i_block = 1 : R
        h_A_pri(:,:,i_block) = u_B_ext( : , (i_block-1)*M+1:i_block*M );
        v_hA_pri(i_block,:) = v_uB_ext( : , (i_block-1)*M+1:i_block*M );
        end
        in_true = find( r==1 ).' ;
        lambda_C_pri = lambda_B_ext ;
        
       %% Modules A and B for b
    if  Update_C == 1
        
         for i_block = 1 : R
             spa = PT/R * (i_block-1) + 1 : PT/R * i_block ;  
             Index_s = Index_sel(spa') ;
             % * b corresponds to the estimates of C in the paper
             [b_A_ext(:,:,i_block),v_bA_ext(i_block,:),b_A_post(:,:,i_block)] = turbo.ModuleA_b('P-DFT',spa,Index_s,h_A_pri(:,:,i_block),v_hA_pri(i_block,:),...
             b_A_pri(:,:,i_block),v_bA_pri(i_block,:),interval,K,PT,R,M , p_total ,sigma_w2) ;
             q_C_pri(:, (i_block-1)*M+1:i_block*M ) = b_A_ext( :,:,i_block ) ;
             v_qC_pri(:, (i_block-1)*M+1:i_block*M ) = v_bA_ext( i_block,: ) ;
        end
        
        [q_C_ext,v_qC_ext,q_C_post,v_q_post,lambda_C_ext,v_q_post_1] = turbo.ModuleC(q_C_pri,v_qC_pri,lambda_C_pri,sigma_c2,R,M) ;

        for i_block = 1 : R
            b_C_post(:,:,i_block) = q_C_post( : , (i_block-1)*M+1:i_block*M );
            v_bC_post(i_block,:) = v_q_post( : , (i_block-1)*M+1:i_block*M );
            b_C_ext(:,:,i_block) = q_C_ext( : , (i_block-1)*M+1:i_block*M );
            v_bC_ext(i_block,:) = v_qC_ext( : , (i_block-1)*M+1:i_block*M );
        end

        b_A_pri = b_C_ext ;
        v_bA_pri  = v_bC_ext ;
        lambda_B_pri = (lambda * lambda_C_ext) ./ ( lambda * lambda_C_ext + (1-lambda)*(1-lambda_C_ext) ) ;
        
            if abs( mean(v_q_post) - mean(v_C_test) )/mean(v_C_test) < 1e-1
                Update_EM = 1 ;
            else
                Update_EM = 0 ;
            end 
  
    end
 
     % termination criterion 
     if abs( mean(v_B_post)- mean(v_B_test))/mean(v_B_post) < 1e-3
            if abs( mean(v_q_post) - mean(v_C_test))/mean(v_q_post) < 1e-3
                  converge = 1 ;
                 break ;
            end
     end 
     
     if j > 10
            if ( mean(v_B_post) >= mean(v_B_test) ) && ( mean(v_q_post,'all') >= mean(v_C_test) )
                 larger = 1 ;
                 break ;
            end
     end 
     
     
     v_B_test = v_B_post ;
     if  Update_C == 1
        v_C_test = v_q_post ;
     end


 
%% EM Update
       if Update_EM == 1     
           lambda_D = lambda_B_ext .* lambda_C_ext ./ ( lambda_B_ext .* lambda_C_ext + (1-lambda_B_ext).*(1-lambda_C_ext) ) ;           
           beta_1 =  ( sum(abs(lambda_D.*u_B_post).^2,'all')  + sum(lambda_D.*v_B_post_1,'all') ) / sum(lambda_D) /(R*M) ;
           gamma_1 = ( sum(abs(lambda_D.*q_C_post).^2,'all') + sum(lambda_D.*v_q_post_1,'all') ) / sum(lambda_D) /(R*M) ;
           lambda_est = sum(lambda_D) / K ;
           if lambda_est < 0.1 && lambda_est > 0.025
               turbo.lambda = lambda_est ;
           end
           
                % beta is \vartheta_H in the paper
                if  beta_1  >  sigma_h2(1) * pri_mul_max
                    beta_1 = sigma_h2(1) * pri_mul_max  ;
                end
                if  beta_1  <  sigma_h2(1) * pri_mul_min
                    beta_1 = sigma_h2(1) * pri_mul_min  ;
                end
                turbo.sigma_h2 = beta_1 * ones(K,1) ;
                sigma_h2 ;
                
                % Gamma is \vartheta_C in the paper
                if  gamma_1  >  gamma_ini * pri_mul_max
                    gamma_1 = gamma_ini * pri_mul_max  ;
                end
                if  gamma_1  <  gamma_ini * pri_mul_min
                    gamma_1 = gamma_ini * pri_mul_min  ;
                end
                sigma_c2 = gamma_1 * ones(K,1) ;
       end
       
       
       % * EM estimation of noise varaince per iteration
       left = zeros(PT,M) ;
       for i_block = 1 : R
            spa = PT/R * (i_block-1) + 1 : PT/R * i_block ;
            left(spa',:) = y(spa',:) - sqrt(p_total) * A(spa',:) * u_B_post( : , (i_block-1)*M+1:i_block*M ) ...
                                     - sqrt(p_total) * interval.* A(spa',:) * b_C_post(:,:,i_block) ; 
       end
       j ;
       sigma_w2_EM_Bpost = mean( (abs(left)).^2,[1,2]  ) ;  %  mean( v_B_post ) * (p_total/PT) * K
       sigma_w2 = sigma_w2_EM_Bpost ;
       if  mean(sigma_w2) < par.sigma_w2 * w_mul_min
                sigma_w2 = par.sigma_w2 * w_mul_min ;
       end     
     
      
     
   %%  results
        [p_false , p_mis , p_error , MSE ] = Result_Turbo_MP(lambda,R,PT, K, M, u_B_post, interval,b_C_post , in_detect_B, h_f_ca, r) ;
        combine_indetect = lambda_B_ext .* lambda_C_ext ./ ( lambda_B_ext .* lambda_C_ext + (1-lambda_B_ext).*(1-lambda_C_ext) ) ;
        sigma_w2_EM_Bpost ;
        beta_1 ; 
        gamma_1 ;
        MSE ;
        
        MSE_sum(j) = MSE + MSE_sum(j) ;
        p_fal_sum(j) = p_false + p_fal_sum(j) ;
        p_mis_sum(j) = p_mis + p_mis_sum(j) ;
        p_error_sum(j) = p_error + p_error_sum(j) ;
                
        
    end 
    
        if j < iter
           MSE_sum( j : end) =  mean(MSE) * ones (iter-j+1,1) + MSE_sum( j : end) ;
           p_fal_sum(j : end) =  p_false * ones (iter-j+1,1) + p_fal_sum(j : end) ;
           p_mis_sum(j : end) =  p_mis * ones (iter-j+1,1) + p_mis_sum(j : end) ;  
           p_error_sum(j : end) =  p_error * ones (iter-j+1,1) + p_error_sum(j : end) ; 
        end

        p_fal_m(:,iter_SNR) = p_fal_sum / k_ex ;
        p_mis_m(:,iter_SNR) = p_mis_sum / k_ex ;
        p_error_m(:,iter_SNR) = p_error_sum / k_ex ;
        NMSE_m(:,iter_SNR) = MSE_sum / k_ex ;
        Num_error = p_error_m(iter,iter_SNR) * K * k_ex ;
   
        
   end 
   
    
  toc

  
end 

%% Result

basePath = [fileparts(mfilename('fullpath')) filesep] ;
data = strcat( basePath ,'Turbo_MP_EM_TDLC.mat') ;
save( data ,'NMSE_m','p_mis_m','p_fal_m','p_error_m') ; 
    
%        figure(1);
%        plot(10*log10(NMSE_m));      
%        figure(2);
%        semilogy(p_error_m);
      
%        figure(1);
%        semilogy(p_mis_m);  
%        title('Miss') ;
%        figure(2);
%        semilogy(p_fal_m);
%        title('False')
%        10*log10(NMSE_m(iter))

%        figure(3); semilogy(v_record_B) ;
%        figure(4); semilogy(v_record_C) ;
