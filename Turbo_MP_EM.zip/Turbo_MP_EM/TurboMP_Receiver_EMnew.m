classdef TurboMP_Receiver_EMnew
    
    properties
        y ;       % the received signal  
        A ;       % the sensing matrix
        sigma_h2 ; %  path-loss
        lambda     % sparsity 
    end
    
    methods
        
        function obj = TurboMP_Receiver_EMnew(y,A,Index_s,sigma_h2,lambda)
            obj.y = y ; 
            obj.sigma_h2 = sigma_h2 ;
            obj.lambda = lambda ;
                if ~isempty(A)
                    obj.A = A ;
                end
                if ~isempty(Index_s)
                    obj.Index_s = Index_s ;
                end
        end
        
        function [h_A_ext,v_hA_ext,sigma_w2_est,h_A_post] = ModuleA_h(obj,type,spa,Index_s,h_A_pri,v_hA_pri,b_A_pri,v_bA_pri,interval,K,PT,R,M,p_total,sigma_w2)
            % Linear estimator
            switch type
                case 'P-DFT'
                Qh =   fft(h_A_pri) / sqrt(PT) ;   Ah = Qh( Index_s', : ) ; 
                Qb =   fft(b_A_pri) / sqrt(PT) ;   Ab = Qb( Index_s', : ) ; 
                r_dual = obj.y(spa',:) - sqrt(p_total) * Ah - sqrt(p_total) * interval .* Ab ;  
                C_inverse = 1./ ( K/(PT/R)*v_hA_pri + K/(PT/R)*interval.^2.*v_bA_pri+ 1/(p_total/R).*sigma_w2 ) ;
                Sr = zeros(K,M);  Sr(Index_s', :) = C_inverse .* r_dual  ;     
                match =  ifft (Sr) * sqrt(K^2/PT) ;
                h_A_post = h_A_pri + v_hA_pri/( sqrt(p_total)/R ) .* match ;
                v_hA_post = v_hA_pri - 1/(PT/R) * v_hA_pri.^2 .* sum(C_inverse,1) ;
                v_hA_ext = 1 ./ ( 1 ./ v_hA_post - 1 ./ v_hA_pri) ;
                J = PT / R ;
                v_h_and_w = sum( abs(r_dual).^2,1 )/ (PT/R) / (p_total/R) ;
                sigma_w2_est =  ( v_h_and_w - K/J*v_hA_pri - K/J*sum(interval.^2)/J*v_bA_pri ) * (p_total/R) ; 
                h_A_ext = v_hA_ext .* ( h_A_post ./ v_hA_post - h_A_pri ./ v_hA_pri );
                
                case 'P-Hadamard'
                Qh =   fwht(h_A_pri) * sqrt(K^2/PT) ;   Ah = Qh( Index_s', : ) ; 
                Qb =   fwht(b_A_pri) * sqrt(K^2/PT) ;   Ab = Qb( Index_s', : ) ; 
                r_dual = obj.y(spa',:) - sqrt(p_total) * Ah - sqrt(p_total) * interval .* Ab ;  
                C_inverse = 1./ ( K/(PT/R)*v_hA_pri + K/(PT/R)*interval.^2.*v_bA_pri+ 1/(p_total/R).*sigma_w2 ) ;
                Sr = zeros(K,M);  Sr(Index_s', :) = C_inverse .* r_dual  ;     
                match =  ifwht (Sr) / sqrt(PT) ;
                h_A_post = h_A_pri + v_hA_pri/( sqrt(p_total)/R ) .* match ;
                v_hA_post = v_hA_pri - 1/(PT/R) * v_hA_pri.^2 .* sum(C_inverse,1) ;
                v_hA_ext = 1 ./ ( 1 ./ v_hA_post - 1 ./ v_hA_pri) ;
                h_A_ext = v_hA_ext .* ( h_A_post ./ v_hA_post - h_A_pri ./ v_hA_pri );
                J = PT / R ;
                v_h_and_w = sum( abs(r_dual).^2,1 )/ (PT/R) / (p_total/R) ;
                sigma_w2_est =  ( v_h_and_w - K/J*v_hA_pri - K/J*sum(interval.^2)/J*v_bA_pri ) * (p_total/R) ;
                
                
            end
            
        end
        
        function [b_A_ext,v_bA_ext,b_A_post] = ModuleA_b(obj,type,spa,Index_s,h_A_pri,v_hA_pri,b_A_pri,v_bA_pri,interval,K,PT,R,M,p_total,sigma_w2)
            % Linear estimator
            switch type
                case 'P-DFT'
                Qh =   fft(h_A_pri) / sqrt(PT) ;   Ah = Qh( Index_s', : ) ; 
                Qb =   fft(b_A_pri) / sqrt(PT) ;   Ab = Qb( Index_s', : ) ; 
                r_dual = obj.y(spa',:) - sqrt(p_total) * Ah - sqrt(p_total) * interval .* Ab ;  
                C_inverse = 1./ (K/(PT/R)*v_hA_pri + K/(PT/R)*v_bA_pri.*interval.^2+ 1/(p_total/R).*sigma_w2) ;
                Sr = zeros(K,M); Sr(Index_s', :) = interval .* C_inverse .* r_dual  ;     
                match =  ifft (Sr) * sqrt(K^2/PT);
                b_A_post = b_A_pri + v_bA_pri/(sqrt(p_total)/R) .* match ;
                v_bA_post = v_bA_pri - 1/(PT/R) * v_bA_pri.^2 .* sum(interval.^2 .* C_inverse , 1) ;
                % 1
                v_bA_ext = 1 ./ ( 1 ./ v_bA_post - 1 ./ v_bA_pri) ; 
                % 2           
                b_A_ext = v_bA_ext .* ( b_A_post ./ v_bA_post - b_A_pri ./ v_bA_pri ); 
                
                case 'P-Hadamard'  
                Qh =   fwht(h_A_pri) * sqrt(K^2/PT) ;   Ah = Qh( Index_s', : ) ; 
                Qb =   fwht(b_A_pri) * sqrt(K^2/PT) ;   Ab = Qb( Index_s', : ) ; 
                r_dual = obj.y(spa',:) - sqrt(p_total) * Ah - sqrt(p_total) * interval .* Ab ;  
                C_inverse = 1./ (K/(PT/R)*v_hA_pri + K/(PT/R)*v_bA_pri.*interval.^2+ 1/(p_total/R).*sigma_w2) ;
                Sr = zeros(K,M);  Sr(Index_s', :) = interval .* C_inverse .* r_dual  ;     
                match =  ifwht (Sr) / sqrt(PT) ;
                b_A_post = b_A_pri + v_bA_pri/(sqrt(p_total)/R) .* match ;
                v_bA_post = v_bA_pri - 1/(PT/R) * v_bA_pri.^2 .* sum(interval.^2 .* C_inverse , 1) ;
                v_bA_ext = 1 ./ ( 1 ./ v_bA_post - 1 ./ v_bA_pri) ; 
                b_A_ext = v_bA_ext .* ( b_A_post ./ v_bA_post - b_A_pri ./ v_bA_pri ); 
                 
            end
            
        end
        
        function [h_B_ext,v_B_ext,lambda_out,in_detect,h_B_post,v_B_post,v_B_post_1] = ModuleB(obj,h_B_pri,v_B_pri,lambda_in ,R, M)
                % MMSE denoiser
                value_on_exp = sum( -( 1./v_B_pri - 1./(obj.sigma_h2+v_B_pri) ).* h_B_pri.* conj(h_B_pri),2 )+ sum(log( 1+(obj.sigma_h2./v_B_pri) ),2) ;
                value_on_exp(value_on_exp > 500) = 500 ;
                phi = 1 ./ (  1 + (1-lambda_in)./lambda_in .*  exp( value_on_exp  )  )  ;
                thres = real(phi) .* obj.sigma_h2 ./ (obj.sigma_h2 + v_B_pri)  ;
                h_B_post = thres .* h_B_pri ;
                v_B_post_1 = real(phi).*(   ( 1 ./ (1./obj.sigma_h2 + 1./v_B_pri) ./ v_B_pri .* abs(h_B_pri) ).^2 + 1 ./ (1./obj.sigma_h2 + 1./v_B_pri)   ) - abs(h_B_post).^2 ;
                v_B_post = mean(v_B_post_1, 1) ;  % approximation: mean of each column
                for m = 1 : M
                    v_B_post(m : M : M*R) = sum( v_B_post(m : M : M*R) ) / R ; 
                end
                v_B_ext = 1 ./ ( 1 ./ v_B_post - 1 ./ v_B_pri) ;
                h_B_ext = v_B_ext .* ( h_B_post ./ v_B_post - h_B_pri ./ v_B_pri );    
                % Detection
                left =  real( sum( -( 1./v_B_pri - 1./(obj.sigma_h2+v_B_pri) ).* h_B_pri.* conj(h_B_pri),2 ) ); % equal
                right = sum(log( 1+(obj.sigma_h2./v_B_pri) ),2) ; % equal
                all_sum =  left + right ;
                all_sum( all_sum > 500 ) = 500 ;
                lambda_out_0 = exp( all_sum ) ;
                lambda_out_1 = 1./( 1 + real(lambda_out_0) ) ; % the Bernoulli message from BG factor node to Bernoulli variable node 
                lambda_out = lambda_out_1 * obj.lambda ./ ( lambda_out_1*obj.lambda + (1-lambda_out_1)*(1-obj.lambda) ) ;
                in_detect = find( lambda_out > 0.5 ) ;

                
             
        end
        
        function [b_C_ext,v_bC_ext,b_C_post,v_C_post,lambda_out,v_q_post_1] = ModuleC(obj,b_C_pri,v_C_pri,lambda_in,sigma_c2,R,M)
                % MMSE denoiser
                value_on_exp = sum( -( 1./v_C_pri - 1./(sigma_c2+v_C_pri) ).* b_C_pri.* conj(b_C_pri),2 )+ sum(log( 1+(sigma_c2./v_C_pri) ),2) ;
                value_on_exp(value_on_exp > 500) = 500 ;
                phi = 1 ./ (  1 + (1-lambda_in)./lambda_in .*  exp( value_on_exp  )  )  ;
                thres = real(phi) .* sigma_c2 ./ (sigma_c2 + v_C_pri)  ;
                b_C_post = thres .* b_C_pri ;
                v_q_post_1 = real(phi).*(   ( 1 ./ (1./sigma_c2 + 1./v_C_pri) ./ v_C_pri .* abs(b_C_pri) ).^2 + 1 ./ (1./sigma_c2 + 1./v_C_pri)   ) - abs(b_C_post).^2 ;
                v_C_post = mean(v_q_post_1, 1) ;  % approximation: mean of each column
                for m = 1 : M
                    v_C_post(m : M : M*R) = sum( v_C_post(m : M : M*R) ) / R ;
                end
                v_bC_ext = 1 ./ ( 1 ./ v_C_post - 1 ./ v_C_pri) ;
                b_C_ext = v_bC_ext .* ( b_C_post ./ v_C_post - b_C_pri ./ v_C_pri ); 
                % Bernoulli distribution
                left = real( - sum( abs(b_C_pri).^2.*(1./v_C_pri-1./(v_C_pri + sigma_c2)) ,2) ) ;
                right = sum( log( (v_C_pri + sigma_c2)./v_C_pri) , 2  ) ;
                all_sum = left + right ;
                all_sum(all_sum > 500) = 500 ; % avoid the Inf value.
                lambda_out = exp(all_sum) ;
                lambda_out = 1./( 1 + real(lambda_out) ) ;                
        end
        
    end
    
end