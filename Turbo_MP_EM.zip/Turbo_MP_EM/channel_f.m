function h_f = channel_f( J, N, K, M, sigma_h2 , user_delay , type , Index_ac)
    

    if  strcmp(type,'TDLA30') == 1
    %  channel model : TDLA 30
    PowerdB = [-13.4 0 -2.2 -4 -6 -8.2 -9.9 -10.5 -7.5 -15.9 -6.6 -16.7 -12.4 -15.2 -10.8 -11.3 -12.7 -16.2 -18.3 -18.9 -16.6 -19 -33.1].' ;
    Delay_t = [0 0.3819 0.4025 0.5868 0.4610 0.5375 0.6708 0.5750 0.7618 1.5375 1.8978 2.2242 2.1718 2.4942 2.5119 3.0582 4.0810 4.4579 4.5695 4.7966 5.0066 5.3043 9.6586].' * 0.1 * 1e-6 ;    
    elseif strcmp(type,'TDLC300') == 1
    % TDLC 300
    PowerdB = [-4.4 -1.2 -3.5 -5.2 -2.5 0 -2.2 -3.9 -7.4 -7.1 -10.7 -11.1 -5.1 -6.8 -8.7 -13.2 -13.9 -13.9 -15.8 -17.1 -16 -15.7 -21.6 -22.8].' ;
    Delay_t = [0 0.209875 0.22187 0.232879 0.217575 0.636635 0.644775 0.655969 0.658398 0.793459 0.821327 0.933566 1.228542 1.308304 2.170372 2.710537 4.258948 4.600331 5.490161 5.60767 6.306541 6.637365 7.042686 8.652312].' * 0.3 * 1e-6 ;
    end    
    Power = 10.^(PowerdB/10) ; 
    Power = Power / sum(Power) ;
    Lch = length(Delay_t) ;
    h_f = zeros( J , K , M ) ; 
    K_ac = length(Index_ac) ;
    
    for k = 1 : K_ac
        Delay_k = Delay_t + user_delay * rand(1) ;
        pathloss = ( randn(Lch,1,M)+1i*randn(Lch,1 ,M) ) .* sqrt(Power.*sigma_h2(Index_ac(k)).'/ 2) ;       
        h_k = pathloss .* exp(-1i * 2 * pi * 15 * 1e3 .* Delay_k .* (1:J) ) ; 
        h_k_shape = reshape( sum(h_k,1) , [J,M] ) ;
        h_f( : , Index_ac(k) , : ) =  h_k_shape  ;
    end        
    
end